package com.assignmentday1;

import java.util.Scanner;

public class TestRectangle {

	public static void main(String[] args) {
		
		//Here i have declared l for length and b for breadth
		int l , b , area ;
		
		//Here i have used scanner so that input can be taken from user
		Scanner s= new Scanner(System.in);
		System.out.println("Enter length of Rectangle");
		l = s.nextInt();
		System.out.println("Enter Breadth of Rectangle");
		b = s.nextInt();
		
		
		area = l * b ;
		System.out.println("Area of Rectangle is "+area);

	}

}
