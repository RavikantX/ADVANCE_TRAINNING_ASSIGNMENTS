package com.assignmentday1;

import java.util.Scanner;

public class ShowBook {

	public static void main(String[] args) {
     Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter the Book name:");
        String bookname=sc.nextLine();
        
        System.out.println("Enter the price:");
        int price=sc.nextInt();
        sc.nextLine();
         
        //Here i have created the object for book
        CreateBook obj=new CreateBook();
        
        //Here i have used the obj.set method to set the price and title
       obj.setBookPrice(price);
       obj.setBookTitle(bookname);
       
        System.out.println("Book Details");
        System.out.println("Book Name :"+obj.getBookTitle());
        System.out.println("Book Price :"+obj.getBookPrice());
    
	}

}
