package com.assignmentday1;

import java.util.Scanner;

public class EvenNumberList {

	public static void main(String[] args) {
		 int n=0,i=0;

		 //I Have Used Scanner to take input from the user
	       Scanner X = new Scanner(System.in);

	       System.out.print("Enter value n : ");

	       n = X.nextInt();

	       for(i=1; i<n; i++)

	       {
              //Logic for Even number
	           if(i%2==0)

	               System.out.print(i+" ");

	       }    

	       System.out.println();
	}

}
