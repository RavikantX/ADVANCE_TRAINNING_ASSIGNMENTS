package com.assignment.day1;

import java.util.Scanner;

public class Rectangle {

	public static void main(String[] args) {
		
		/*As per the question requirement i have to provide the length and breadth between 0.0 and 20.0 
		 so i have given 6.6 and 12.5 Respectively */
		 
		final double length = 6.6;
        final double breadth = 12.5;

        double perimeter = 2*(length + breadth);
		
        double area = length * breadth;			
		
		System.out.printf("Perimeter is 2*(%.1f + %.1f) = %.2f \n", length, breadth, perimeter);

        System.out.printf("Area is %.1f * %.1f = %.2f \n", length, breadth, area);	
		
		}
	}