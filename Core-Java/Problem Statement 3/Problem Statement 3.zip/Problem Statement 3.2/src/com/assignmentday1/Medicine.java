package com.assignmentday1;

public class Medicine {

	{
		String date;
		int P;}
		public void getDetails(int P,String date)
		{
		System.out.println("Price");
		System.out.println("Expiry date");
		}
		public void displayLabel()
		{
		System.out.println("Company : Shanti Pharma");
		System.out.println("Address : Sonepur");
		}}
		class Tablet extends Medicine
		{
		
		public void displayLabel()
		{
		System.out.println("store in a cool dry place");
		}}
		class Syrup extends Medicine
		{
		public void displayLabel()
		{
		System.out.println("Consumption as directed by the physician");
		}}
		class Ointment extends Medicine
		{
		public void displayLabel()
		{
		System.out.println("for external use only");
		}}
		