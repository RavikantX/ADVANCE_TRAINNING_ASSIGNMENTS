package com.assignmentday1;

public class Student {

}
