package com.assignmentday1;

public class Sum {

	public static void main(String[] args) {
		
		//I have Used Login to print the next 13 numbers
		int i = 1, n = 13, firstTerm = 0, secondTerm = 1;
	    System.out.println("Fibonacci Series till " + n + " terms:");

	    while (i <= n) {
	      System.out.print(firstTerm + ", ");

	      int nextTerm = firstTerm + secondTerm;
	      firstTerm = secondTerm;
	      secondTerm = nextTerm;

	      i++;
	}
	}
}
