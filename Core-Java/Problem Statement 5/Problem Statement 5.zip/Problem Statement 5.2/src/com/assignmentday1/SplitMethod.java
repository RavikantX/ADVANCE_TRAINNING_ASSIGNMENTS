package com.assignmentday1;

public class SplitMethod {

	public static void main(String[] args) {
		String str = "23  +  45  -(  343  /  12  )";
        String[] splits = str.split(" ");
        //This regEx splits the String on the WhiteSpaces 
        for(String s: splits) {
            System.out.println(s);
        }
	}

}
